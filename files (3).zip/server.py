from flask import Flask, jsonify, request, send_from_directory, Response
from flask_cors import CORS
import time, urllib.parse, re, threading, uuid, requests
from bs4 import BeautifulSoup

app = Flask(__name__, static_folder='.')
CORS(app)

H = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
}
jobs = {}

def nm(t): return re.sub(r'[^a-z0-9 ]', '', t.lower()).strip()
def pc(x):
    n = re.findall(r'\d+', str(x).replace(',', ''))
    return int(n[0]) if n else 0

# ── WTR Lab duplicate check via Playwright ────────────────────
_c = {}
def is_on_wtrlab(title, log=None):
    n = nm(title)
    if n in _c: return _c[n]
    try:
        from playwright.sync_api import sync_playwright
        encoded = urllib.parse.quote(title)
        url = f'https://wtr-lab.com/en/novel-finder?text={encoded}'
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            ctx = browser.new_context(user_agent=H['User-Agent'])
            page = ctx.new_page()
            page.goto(url, wait_until='domcontentloaded', timeout=20000)
            time.sleep(2)
            html = page.content()
            browser.close()
        soup = BeautifulSoup(html, 'html.parser')
        page_text = soup.get_text().lower()
        if 'no novel found' in page_text or 'no result' in page_text:
            _c[n] = False; return False
        if title in html:
            _c[n] = True; return True
        wa = set(n.split())
        if wa:
            page_words = set(nm(soup.get_text()).split())
            if len(wa & page_words) / max(len(wa), 1) >= 0.7:
                _c[n] = True; return True
        _c[n] = False; return False
    except Exception as e:
        if log: log(f'WTR check error: {e}', 'warn')
        _c[n] = None; return None

# ── Playwright browser fetcher ────────────────────────────────
def pw_get(url, wait=2, log=None):
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            ctx = browser.new_context(
                user_agent=H['User-Agent'],
                extra_http_headers={'Accept-Language': 'zh-TW,zh;q=0.9,en;q=0.8'}
            )
            page = ctx.new_page()
            page.goto(url, wait_until='domcontentloaded', timeout=45000)
            time.sleep(wait)
            html = page.content()
            browser.close()
            return html
    except Exception as e:
        if log: log(f'Browser error on {url}: {e}', 'warn')
        return None

# ── Parsers ───────────────────────────────────────────────────
def parse_69shu(html, mc):
    soup = BeautifulSoup(html, 'html.parser')
    res = []
    for li in soup.select('ul li'):
        a = li.select_one('a[href*="/book/"]')
        if not a: continue
        href = a.get('href', '')
        url = href if href.startswith('http') else 'https://www.69shuba.com' + href
        title_el = li.select_one('h3.ellipsis_1, h3')
        title = title_el.get_text(strip=True) if title_el else a.get_text(strip=True)
        if not title: continue
        author_el = li.select_one('h4')
        author = author_el.get_text(strip=True) if author_el else 'Unknown'
        chap_el = li.select_one('.zs, [class*=chap], [class*=count]')
        chaps = pc(chap_el.get_text()) if chap_el else 999
        if chaps == 0: chaps = 999
        if chaps >= mc:
            res.append({'title': title, 'author': author, 'chapters': chaps, 'url': url, 'source': '69shuba.com'})
    return res

def parse_twkan(html, mc):
    soup = BeautifulSoup(html, 'html.parser')
    res = []
    for li in soup.select('ul li'):
        a = li.select_one('a[href*="/book/"]')
        if not a: continue
        href = a.get('href', '')
        url = href if href.startswith('http') else 'https://twkan.com' + href
        title_el = li.select_one('h3.ellipsis_1, h3')
        title = title_el.get_text(strip=True) if title_el else a.get_text(strip=True)
        if not title: continue
        author_el = li.select_one('h4')
        author = author_el.get_text(strip=True) if author_el else 'Unknown'
        chap_el = li.select_one('.zs, [class*=chap], [class*=count]')
        chaps = pc(chap_el.get_text()) if chap_el else 999
        if chaps == 0: chaps = 999
        if chaps >= mc:
            res.append({'title': title, 'author': author, 'chapters': chaps, 'url': url, 'source': 'twkan.com'})
    return res

def parse_uuread(html, mc):
    soup = BeautifulSoup(html, 'html.parser')
    res = []
    seen = set()
    # Try multiple selectors for uuread's layout
    for a in soup.select('a[href*="uuread.tw/"], .media-body a, strong.text-more a, a[title]'):
        href = a.get('href', '')
        if not href or not re.search(r'/\d+', href): continue
        if href in seen: continue
        seen.add(href)
        title = a.get('title', '') or a.get_text(strip=True)
        if not title or len(title) < 2: continue
        url = href if href.startswith('http') else 'https://www.uuread.tw' + href
        # Get author from parent text
        parent = a.find_parent('div') or a.find_parent('li') or a.find_parent()
        author = 'Unknown'
        if parent:
            txt = parent.get_text(' ', strip=True)
            if '/' in txt:
                parts = [p.strip() for p in txt.split('/')]
                if len(parts) > 1 and len(parts[-1]) < 30:
                    author = parts[-1]
        res.append({'title': title, 'author': author, 'chapters': 999, 'url': url, 'source': 'uuread.tw'})
    return res

# ── Genre maps ────────────────────────────────────────────────
SORT_GENRES = {
    'fantasy':  ['1'],
    'xianxia':  ['2'],
    'romance':  ['3'],
    'action':   ['4', '7'],
    'mystery':  ['5'],
    'sci-fi':   ['14'],
    'horror':   ['15'],
    'history':  ['6'],
    'urban':    ['8'],
    'game':     ['9'],
    'sports':   ['10'],
    'military': ['11'],
    'comedy':   ['12'],
    'danmei':   ['13'],
    'other':    ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15'],
}

UUREAD_GENRES = {
    'fantasy':  ['xuanhuan'],
    'xianxia':  ['xianxia', 'xiuzhen'],
    'romance':  ['yanqing', 'dushi'],
    'action':   ['wuxia', 'dongfang'],
    'mystery':  ['xuanyi'],
    'sci-fi':   ['kehuan'],
    'horror':   ['kongbu'],
    'history':  ['lishi', 'gudai'],
    'urban':    ['dushi', 'xiandai'],
    'game':     ['youxi'],
    'sports':   ['tiyu'],
    'military': ['junshi'],
    'comedy':   ['qingchun'],
    'danmei':   ['danmei'],
    'other':    ['xuanhuan','xianxia','yanqing','wuxia','xuanyi','kehuan','kongbu','lishi','dushi','youxi','junshi'],
}

def scrape_69shu(genre, mc, log, max_pages=15):
    res = []
    genre_ids = SORT_GENRES.get(genre, ['1'])
    for gid in genre_ids:
        log(f'69shuba genre {gid} — scraping up to {max_pages} pages...')
        empty_count = 0
        for p in range(1, max_pages + 1):
            url = f'https://www.69shuba.com/sort.htm?c={gid}&page={p}'
            html = pw_get(url, wait=2, log=log)
            if not html:
                empty_count += 1
                if empty_count >= 2: break
                continue
            batch = parse_69shu(html, mc)
            if not batch:
                empty_count += 1
                if empty_count >= 2: break
                continue
            empty_count = 0
            res += batch
            log(f'  69shuba page {p}/genre {gid}: +{len(batch)} novels (total {len(res)})', 'dim')
            time.sleep(1.5)
    log(f'69shuba total: {len(res)} novels')
    return res

def scrape_twkan(genre, mc, log, max_pages=15):
    res = []
    genre_ids = SORT_GENRES.get(genre, ['1'])
    for gid in genre_ids:
        log(f'twkan genre {gid} — scraping up to {max_pages} pages...')
        empty_count = 0
        for p in range(1, max_pages + 1):
            url = f'https://twkan.com/sort.htm?c={gid}&page={p}'
            html = pw_get(url, wait=2, log=log)
            if not html:
                empty_count += 1
                if empty_count >= 2: break
                continue
            batch = parse_twkan(html, mc)
            if not batch:
                empty_count += 1
                if empty_count >= 2: break
                continue
            empty_count = 0
            res += batch
            log(f'  twkan page {p}/genre {gid}: +{len(batch)} novels (total {len(res)})', 'dim')
            time.sleep(1.5)
    log(f'twkan total: {len(res)} novels')
    return res

def scrape_uuread(genre, mc, log, max_pages=10):
    res = []
    cats = UUREAD_GENRES.get(genre, ['xuanhuan'])
    for cat in cats:
        base = f'https://www.uuread.tw/{cat}/'
        log(f'uuread /{cat}/ — scraping up to {max_pages} pages...')
        empty_count = 0
        for p in range(1, max_pages + 1):
            url = f'{base}?page={p}' if p > 1 else base
            html = pw_get(url, wait=3, log=log)
            if not html:
                empty_count += 1
                if empty_count >= 2: break
                continue
            batch = parse_uuread(html, mc)
            if not batch:
                empty_count += 1
                if empty_count >= 2: break
                continue
            empty_count = 0
            res += batch
            log(f'  uuread /{cat}/ page {p}: +{len(batch)} novels (total {len(res)})', 'dim')
            time.sleep(2)
    log(f'uuread total: {len(res)} novels')
    return res

def scrape_fanqi(genre, mc, log, max_pages=10):
    FANQI_G = {'fantasy':'4','romance':'6','action':'1','mystery':'14','sci-fi':'15','horror':'16','history':'7','other':'0'}
    gid = FANQI_G.get(genre, '0')
    res = []
    log(f'fanqienovel — scraping up to {max_pages} pages...')
    for p in range(1, max_pages + 1):
        url = f'https://fanqienovel.com/library?page_count={p}&genre={gid}&order=0'
        html = pw_get(url, wait=3, log=log)
        if not html: break
        soup = BeautifulSoup(html, 'html.parser')
        items = soup.select('div.stack-book-item, div[class*="book-item"]')
        batch = []
        for item in items:
            a = item.select_one('a.book-item-title, a[href*="/page/"]')
            if not a: continue
            title = a.get_text(strip=True)
            if not title or len(title) < 2: continue
            href = a.get('href', '')
            u = href if href.startswith('http') else 'https://fanqienovel.com' + href
            author_el = item.select_one('[class*=author]')
            author = author_el.get_text(strip=True).replace('Author:', '').strip() if author_el else 'Unknown'
            chap_el = item.select_one('[class*=count],[class*=chap],[class*=word]')
            chaps = pc(chap_el.get_text()) if chap_el else 999
            if chaps > 10000: chaps = chaps // 3000
            if chaps == 0: chaps = 999
            if chaps >= mc:
                batch.append({'title': title, 'author': author, 'chapters': chaps, 'url': u, 'source': 'fanqienovel.com'})
        if not batch: break
        res += batch
        log(f'  fanqi page {p}: +{len(batch)} novels (total {len(res)})', 'dim')
        time.sleep(1)
    log(f'fanqi total: {len(res)} novels')
    return res

def check_manual_urls(urls, log):
    res = []
    log(f'Processing {len(urls)} manual URLs...')
    for url in urls:
        url = url.strip()
        if not url or not url.startswith('http'): continue
        src = 'unknown'
        for k, v in [('fanqi','fanqienovel.com'),('69shu','69shuba.com'),('twkan','twkan.com'),('uuread','uuread.tw'),('tadu','tadu.com'),('qimao','qimao.com')]:
            if k in url: src = v; break
        try:
            html = pw_get(url, wait=2, log=log)
            if html:
                soup = BeautifulSoup(html, 'html.parser')
                title_el = soup.select_one('h1, .book-name, [class*=title]')
                title = title_el.get_text(strip=True) if title_el else url
                author_el = soup.select_one('[class*=author]')
                author = author_el.get_text(strip=True) if author_el else 'Unknown'
            else:
                title = url; author = 'Unknown'
        except:
            title = url; author = 'Unknown'
        res.append({'title': title, 'author': author, 'chapters': 0, 'url': url, 'source': src})
    return res

def matches_tags(novel, tags):
    if not tags: return True
    title_lower = novel['title'].lower()
    author_lower = novel['author'].lower()
    for tag in tags:
        if tag.lower() in title_lower or tag.lower() in author_lower:
            return True
    return False

def run_job(jid, genre, mc, sources, manual_urls=None, tags=None):
    job = jobs[jid]
    def log(m, lv='info'): job['logs'].append({'msg': m, 'level': lv})
    try:
        all_r = []
        if manual_urls:
            all_r = check_manual_urls(manual_urls, log)
        else:
            scraper_map = {
                'fanqi':  lambda: scrape_fanqi(genre, mc, log),
                '69shu':  lambda: scrape_69shu(genre, mc, log),
                'twkan':  lambda: scrape_twkan(genre, mc, log),
                'uuread': lambda: scrape_uuread(genre, mc, log),
            }
            for i, src in enumerate(sources):
                if src in scraper_map:
                    all_r += scraper_map[src]()
                job['progress'] = int(10 + ((i+1)/len(sources))*40)

        # Filter by tags if any selected
        if tags:
            before = len(all_r)
            all_r = [n for n in all_r if matches_tags(n, tags)]
            log(f'Tag filter: {before} → {len(all_r)} novels match tags: {", ".join(tags)}')

        # Deduplicate by URL
        seen = set(); uniq = []
        for n in all_r:
            if n['url'] not in seen:
                seen.add(n['url']); uniq.append(n)

        log(f'Dedup: {len(all_r)} → {len(uniq)} unique novels found')
        job['progress'] = 52
        log(f'Checking {len(uniq)} novels against WTR Lab (this takes a while)...')
        nc = dc = uc = 0

        for i, nv in enumerate(uniq):
            r = is_on_wtrlab(nv['title'], log)
            if r is True:    nv['wtr_status'] = 'duplicate'; dc += 1
            elif r is False: nv['wtr_status'] = 'new';       nc += 1
            else:            nv['wtr_status'] = 'unverified'; uc += 1
            job['results'].append(nv)
            job['progress'] = int(52 + ((i+1)/len(uniq))*46)
            if (i+1) % 5 == 0 or i == len(uniq)-1:
                log(f'[{i+1}/{len(uniq)}] {nc} new · {dc} dupes · {uc} unverified', 'dim')
            time.sleep(1)

        log(f'✦ Done! {nc} new · {dc} duplicates · {uc} unverified', 'ok')
        job['status'] = 'done'
    except Exception as e:
        log(f'Error: {e}', 'err')
        job['status'] = 'error'

@app.route('/')
def index(): return send_from_directory('.', 'index.html')

@app.route('/api/search', methods=['POST'])
def api_search():
    d = request.json; jid = str(uuid.uuid4())
    jobs[jid] = {'status': 'running', 'progress': 0, 'logs': [], 'results': []}
    threading.Thread(
        target=run_job,
        args=(jid, d.get('genre','fantasy'), int(d.get('min_chapters',100)),
              d.get('sources',['69shu','twkan','uuread']), d.get('manual_urls'),
              d.get('tags', [])),
        daemon=True
    ).start()
    return jsonify({'job_id': jid})

@app.route('/api/job/<jid>')
def api_job(jid):
    j = jobs.get(jid)
    return jsonify({'status':j['status'],'progress':j['progress'],'logs':j['logs'],'results':j['results']}) if j else (jsonify({'error':'Not found'}),404)

@app.route('/api/export/<jid>')
def api_export(jid):
    j = jobs.get(jid)
    if not j: return jsonify({'error':'Not found'}), 404
    fields = ['title','author','chapters','url','source','wtr_status']
    rows = [','.join(fields)] + [
        ','.join(f'"{str(n.get(f,"")).replace(chr(34),chr(39))}"' for f in fields)
        for n in j['results'] if n.get('wtr_status') != 'duplicate'
    ]
    return Response('\n'.join(rows), mimetype='text/csv',
                    headers={'Content-Disposition':'attachment; filename=wtrlab_results.csv'})

if __name__ == '__main__':
    print('\n' + '='*50)
    print('  WTR Lab Novel Finder — Backend Server')
    print('='*50)
    print('  Server running at: http://localhost:5000')
    print('  Press Ctrl+C to stop\n')
    app.run(debug=False, port=5000)
